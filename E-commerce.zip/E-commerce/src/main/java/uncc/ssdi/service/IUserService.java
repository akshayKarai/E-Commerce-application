package uncc.ssdi.service;

import uncc.ssdi.model.User;

public interface IUserService {

	

	

	public User addUser(User u);

	public User checkUser(User S);
}
