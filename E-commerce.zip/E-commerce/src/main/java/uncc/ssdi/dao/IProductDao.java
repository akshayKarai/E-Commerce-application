package uncc.ssdi.dao;

import java.util.List;

import uncc.ssdi.model.IProduct;

public interface IProductDao {
	//public Iterable<IProduct> geAlltProducts();
}
