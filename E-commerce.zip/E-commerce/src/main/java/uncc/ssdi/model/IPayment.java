package uncc.ssdi.model;

public interface IPayment {

}
