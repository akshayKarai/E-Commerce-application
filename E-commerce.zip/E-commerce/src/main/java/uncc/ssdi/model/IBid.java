package uncc.ssdi.model;

public interface IBid {

}
